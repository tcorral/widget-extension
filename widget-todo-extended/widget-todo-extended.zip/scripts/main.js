import baseWidget from 'base-widget-ng';

module.name = 'widget-todo-extended'; 

export default function (widget) {
    baseWidget(widget, module);
};